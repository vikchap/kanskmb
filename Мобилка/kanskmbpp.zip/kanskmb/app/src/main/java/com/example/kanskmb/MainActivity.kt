package com.example.kanskmb

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btn_home).setOnClickListener {
        }
        findViewById<Button>(R.id.btn_info_org).setOnClickListener {
            startActivity(Intent(this, InfoOrgActivity::class.java))
        }
        findViewById<Button>(R.id.btn_info_patients).setOnClickListener {
            startActivity(Intent(this, InfoPatientsActivity::class.java))
        }
        findViewById<Button>(R.id.btn_workers).setOnClickListener {
            startActivity(Intent(this, WorkersActivity::class.java))
        }
        findViewById<Button>(R.id.btn_contacts).setOnClickListener {
            startActivity(Intent(this, ContactsActivity::class.java))
        }
    }
}
