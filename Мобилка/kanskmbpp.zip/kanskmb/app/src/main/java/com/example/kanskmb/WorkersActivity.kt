package com.example.kanskmb

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class WorkersActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_workers)
    }
}
